<?php

$token = "6789334367:AAHp_YSNShci064rvLfC5Ap5HJNBVaNjUco";
$id = 5403131968;

?>